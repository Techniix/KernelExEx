KernelExEx 1.0.0 test build 25 for real-hardware testing (Windows 98 SE / ME)

New in build 2: a driver for Intel PRO/1000 network adapters (OpenBSD's em
driver running on Windows 98), see step 6.
New in build 3: USB networking, including USB tethering from an Android
phone (OpenBSD's urndis driver), see step 7.
New in build 4: Wi-Fi for Realtek USB adapters such as the TP-Link
TL-WN722N v2/v3 and TL-WN725N (OpenBSD's urtwn driver and wireless stack,
WPA2), see step 8; USB CDC Ethernet adapters, see step 9; and every
network driver now writes its messages to C:\WINDOWS\KEXNET.LOG.
New in build 5: a second Realtek Wi-Fi driver, from FreeBSD (rtwn), for
newer adapters including the TP-Link Archer T2U Plus (RTL8821AU), T2U,
T2U Nano and other RTL8812AU/8821AU/8188FU/8723BU sticks. It now handles
the older Realtek chips too; build 4's driver stays for the few it lacks.
New in build 6: for boards like the MSI 848P Neo2-V: a driver for the
onboard Realtek RTL8100C network chip (and every RTL8139-family card),
see step 10, and chipset INFs that name every part of Intel ICH2 to
ICH10 chipsets, so Device Manager has no unknown devices, see step 11.
New in build 7: sound for onboard AC'97 audio (the MSI 848P Neo2-V's ICH5
with its Realtek ALC655, and other Intel, nVidia and AMD boards), see
step 12. Every driver also got a fix for memory Windows 98 does not
clear for drivers: if a network driver from an earlier build misbehaved
on your hardware, please try it again with this build.
New in build 8: USB 2.0 (step 13). Windows 98 runs USB 2.0 ports at
USB 1.1 speed; this driver runs USB 2.0 devices at full USB 2.0 speed,
including the T2U Plus Wi-Fi stick. USB 1.1 devices (mice, keyboards)
stay on Windows' own drivers.
New in build 9: disks over 128 GB (step 14). KernelExEx now has its own
version numbers: this is "1.0.0 test build 9" (builds 1 to 8 were
"4.7.0-hwtest"). Also fixed: the chipset INFs (step 11) did not set up
the two IDE channels of the IDE and SATA controllers they name, so
Windows ran those disks in slow MS-DOS compatibility mode; if you
installed step 11 before, please do it again with this build.

New in build 22: the laptop battery (step 21). On laptops whose battery
Windows 98 cannot read (most from 2005 on), a new component shows the
charge and time left on the taskbar and warns when it runs low. Only for
a laptop; nothing else changed since build 21.

New in build 21: the AHCI and NVMe drivers (step 20) are faster: they
now use the controller's interrupt and send a disk several commands at
once (NCQ on SATA). Windows can also start from a disk in AHCI mode now.
Like build 20, this only matters for a newer PC; on the MSI 848P
nothing changed since build 19.

New in build 20: drivers for SATA in AHCI mode and for NVMe SSDs
(step 20), for newer PCs. Your MSI 848P board has neither (its SATA
is the older IDE kind), so this is only for another PC if you have
one. Everything else is as in build 19.

New in build 19: a fix for the exFAT component (step 19): about one
boot in seven could hang with it installed. Use this build rather than
18 for step 19.

New in build 18: exFAT cards and sticks get a drive letter and can be
read (step 19, optional, read-only for now). Nothing else changed
since build 17, so the T2U Plus, AC'97 and LAN tests from build 17
still stand.

New in build 17: the T2U Plus (and other RTL8812AU/8821AU sticks with
three or more transmit endpoints) failed to start with Code 10: the
driver puts two of its transmit queues on one USB endpoint, and our USB
layer refused that. Found and fixed with a simulated T2U Plus in the
test VM, where the driver now starts, loads the chip's firmware and
scans, both on USB 1.1 and on USB 2.0 ports.

New in build 16:
  - AC'97 sound on the MSI 848P Neo2-V: your board connects its ALC655 to
    the ICH5's third codec input; the driver only looked at the first and
    gave up (Code 10, "no codec ready (GLOB_STA 10700000)"). It now takes
    a codec on any of the three.
  - Every network and Wi-Fi driver now also writes its start report to
    the registry, like the sound driver: HKEY_LOCAL_MACHINE\Software\
    KernelEx\Diag, values "kexnet-rl" (onboard LAN), "kexnet-rtwn" (T2U
    Plus) and so on. Unlike KEXNET.LOG this works while Windows is still
    starting. If a value is missing, the driver never loaded at all.

New in build 15: a network or Wi-Fi adapter that fails to start (Code 10)
now still writes C:\WINDOWS\KEXNET.LOG, saying why. Before, only a
running adapter wrote it.

New in build 14: the onboard Realtek LAN driver (step 10) now silences
the chip (interrupts off, receiver stopped) the moment it finds it,
before Windows connects its interrupt. A boot ROM or BIOS can leave the
chip running, and the startup hang with the 848P Neo2-V's RTL8100C may
come from that. Everything else is as in build 13.

New in build 13:
  - Updating over an earlier build no longer stops with "Error opening
    file for writing" (kexwifi.exe, kexwifi.cpl, kexntp.exe). Files that
    a running program holds are replaced at the restart.
  - Xbox 360-style controllers, your 8BitDo Ultimate 2C included: the
    driver stopped with Code 10 on every real Xbox 360-protocol pad (these
    pads have four parts and Windows wants them all set up at once).
    Fixed, and the sticks now read correctly in Control Panel, Game
    Controllers (they all sat in one corner before).
  - AC'97 sound (step 12): Windows' own sound system files (portcls.sys
    and others) now come with the driver from your Windows 98 CD when
    Windows sets the sound chip up; setup tells you when the CD will be
    asked for. If the sound chip shows Code 2, setup has it set up again
    after the restart.
  - "Recommended" in setup now ticks: the internet and API parts, clock
    sync, XInput, every driver for USB devices (Wi-Fi, USB storage,
    controllers, tethering; each loads only when its device is plugged
    in), and the drivers for the hardware setup finds in your PC. Never
    ticked by itself: "Disks over 128 GB" and Protoweb.

New in build 12:
  - Wi-Fi program (step 16): a Wi-Fi icon on the taskbar and in Control
    Panel to pick a network and type its password, instead of the
    adapter's Advanced properties. For your T2U Plus when it arrives.
  - Setup looks new (logo, grouped components, install types "Recommended",
    "Full", "KernelEx only"; step 17). The component names in the older
    steps below have changed a little; they are now under "Hardware
    drivers".
  - Drivers ticked in setup are now found by Windows by itself when it
    finds the device: no more "Specify a location". (Windows 98's wizard
    turned out not to look where setup used to tell it.)
  - Virtual machines (step 18): a virtio network driver and mouse
    integration for QEMU and VMware.
  - Fixes found while testing, in every USB network driver (USB Wi-Fi,
    tethering, USB Ethernet): Windows could freeze a few seconds after the
    driver started, or hang at the startup screen while waiting for an
    address. Also in the USB 2.0 driver's log. If your PC ever hung at the
    startup screen with one of these, that was probably it.

New in build 11: USB flash drives, USB hard disks, card readers and USB
CD/DVD drives, with no driver disk (step 15). Build 10's fixes are still
in, see below; if you have not sent the AC'97 "kexac97" value yet, it
is still wanted.

New in build 10: fixes from your first test on the MSI 848P Neo2-V.
  - The Realtek network driver (step 10) could take over interrupts of
    other devices sharing its IRQ, which hangs Windows at the start
    screen. Fixed (the Intel PRO/1000 driver got the same check).
    Windows remembers the hang (Code 11) and will not try the device
    again by itself: in Device Manager, select "Realtek RTL8139/810x
    Fast Ethernet", Remove, then Refresh (or restart) and point the New
    Hardware wizard at drivers\realtek-lan.
  - The AC'97 sound driver (step 12) now records why it did not start
    (Code 10). After installing it and restarting: Start > Run >
    regedit, open HKEY_LOCAL_MACHINE\Software\KernelEx\Diag and send
    a photo of the "kexac97" value (or File > Export that key).
    Update its driver first: Device Manager, the AC'97 controller,
    Driver tab, Update Driver, point it at drivers\audio-ac97.

Tested so far in QEMU on Windows 98 SE (Korean): clean install, boot to
desktop, KernelEx enabled, Unicode layer and TLS self-test pass.

BEFORE YOU START
  - Use a machine (or disk image) you can afford to restore.
  - Optional: put unicows.exe (Microsoft MSLU) next to the installer;
    without it KernelExEx uses its own Unicode layer.

1. Run tests\kexuni_test.exe in a DOS box BEFORE installing.
   Expect: 20/20 passed.
2. Run KernelExEx-setup.exe. Defaults are fine (Game controllers ticked,
   Protoweb not ticked). Choose Reboot now.
3. After the reboot: a KernelEx message box says it is installed.
4. In a DOS box, from the tests folder:
     kexuni_test.exe                    expect 20/20 passed
     kexnet_test.exe selftest           expect SELFTEST OK
     kexnet_test.exe get https://example.com/
                                        expect HTTP 200 and page text
5. Optional: plug in your 8BitDo Ultimate 2C (USB, XInput mode).
   Device Manager should show a KernelExEx game controller. Send the
   VID/PID shown there (Properties > Details) if it is not picked up.

6. Optional, if the machine has an Intel PRO/1000 / 8254x / 8257x /
   82566-82579 / I210-I219 / I350 network adapter (many onboard Intel
   chipsets, PCI and PCIe cards). Either tick "Network adapter drivers >
   Intel PRO/1000" in setup, or point Windows at drivers\intel-pro1000
   when it asks for a driver (Device Manager > the Ethernet controller >
   Reinstall driver > specify a location).
   Expect in Device Manager: "Intel <model> (KernelExEx)", working properly.
   Expect in Control Panel > Network: the adapter and "TCP/IP -> Intel ...".
   Then in a DOS box:  ipconfig   (an address from your router)
                       ping <your router's address>
                       tests\kexnet_test.exe get https://example.com/
   Please send: the model name Device Manager shows, the ipconfig output,
   and whether ping and the HTTPS fetch work.
   Note: if Windows ever crashes while the adapter is starting, Windows
   stops starting TCP/IP on it for good (TCP/IP shows as bound, ipconfig
   does not list the adapter). Remove the adapter in Device Manager and
   let Windows find it again to clear that.

7. Optional: USB tethering from an Android phone (or any RNDIS USB network
   adapter). Needs Windows 98 SE's USB support working (a USB controller in
   Device Manager, no yellow marks).
   On the phone: plug in the USB cable, then Settings > Network > Hotspot &
   tethering > USB tethering ON.
   Windows finds new hardware: choose "Specify a location" and point it at
   drivers\usb-rndis. (Or tick "Network adapter drivers > USB RNDIS" in
   setup first, then Windows finds it by itself.)
   If Windows says it found no driver, send the VID and PID: Device
   Manager > the unknown USB device > Properties; or tell me the phone
   model, and I will add its ID.
   Expect: "Android USB tethering (...) (KernelExEx)" under Network
   adapters, then in a DOS box: ipconfig (an address like 192.168.42.x),
   ping 8.8.8.8, and tests\kexnet_test.exe get https://example.com/.

8. Optional: Wi-Fi with a Realtek USB adapter. Your TP-Link Archer T2U
   Plus (RTL8821AU, USB ID 2357:0120) is the one to try first.
   Brand new: the driver has never run on a real adapter, so expect to
   send me a log or two.
   Plug it in. When Windows finds it, choose "Specify a location" and point
   it at drivers\wifi-realtek. (Or tick "Network adapter drivers >
   Realtek USB Wi-Fi (FreeBSD rtwn)" in setup first.) Windows should call
   it "Realtek RTL8821AU USB Wi-Fi (TPLINK T2UPLUS)".
   drivers\wifi-realtek-old is build 4's driver, only for the few older
   adapters the new one does not list.
   Then Control Panel > Network > the adapter > Properties > Advanced:
     Network name (SSID)      your Wi-Fi name, exactly (case matters)
     WPA2 passphrase          your Wi-Fi password (leave empty only for
                              an open network)
     Allow older WPA (TKIP)   leave at No unless your router only does WPA
   OK, then restart. The passphrase is stored in the registry, like
   Windows 98 stores other network settings.
   The adapter comes up about 10 seconds after Windows starts (it loads
   the Realtek firmware then), so wait half a minute before testing:
     ipconfig   ping <your router>   tests\kexnet_test.exe get https://example.com/
   The board's USB ports run at USB 1.1 speed under Windows 98 for now
   (USB 2.0 support is coming), so expect a few Mbit/s, not more.
   The T2U Plus does 2.4 GHz and 5 GHz; this build uses 20 MHz channels,
   WPA2 (not WPA3-only networks).
   Please send, whether it works or not:
     - C:\WINDOWS\KEXNET.LOG (rewritten every 10 seconds; copy it after
       waiting a minute or so)
     - what Device Manager shows for the adapter (any yellow mark, and its
       Properties > General text)
     - what your router uses: WPA2 or WPA3, 2.4 GHz or 5 GHz

9. Optional: a USB Ethernet adapter, or a phone/modem offering "CDC
   Ethernet" (ECM). Point Windows at drivers\usb-ethernet. Realtek
   RTL8152/8153 adapters (most cheap USB 3 to Ethernet dongles) are listed
   but only work if they offer the standard CDC mode; send KEXNET.LOG if
   one shows up but gets no address.

10. Network: Realtek RTL8139 family (onboard RTL8100C on the MSI 848P
   Neo2-V; RTL8139 cards such as the D-Link DFE-530TX+). Windows 98 has
   no driver for these. When Windows finds "PCI Ethernet Controller",
   choose "Specify a location" and point it at drivers\realtek-lan. (Or
   tick "Network adapter drivers > Realtek RTL8139/810x" in setup.) If
   Windows already shows it under "Other devices" with a "?", remove it
   in Device Manager and restart: Windows finds it again.
   Device Manager should then show "Realtek RTL8139/810x Fast Ethernet".
   Test: ipconfig, ping your router, tests\kexnet_test.exe get
   https://example.com/. If it fails, send C:\WINDOWS\KEXNET.LOG.

11. Chipset: tick "Intel chipset support" in setup (or, for one device,
   point Windows at drivers\chipset). Setup makes Windows find again
   the Intel devices it had no driver for; at the next start, accept
   the New Hardware wizard's suggestions. Afterwards Device Manager
   should list the ICH5 SMBus, LPC bridge, IDE and SATA controllers
   and four USB controllers by name, with no yellow marks except the
   AC'97 audio and USB 2.0 (EHCI) controllers: drivers for those are
   coming. Please send a screenshot of Device Manager (View devices by
   type, everything expanded) before and after.

12. Sound: AC'97 audio (onboard on the MSI 848P Neo2-V: ICH5 + ALC655).
   Windows 98 has no driver for it. When Windows finds "PCI Multimedia
   Audio Device", choose "Specify a location" and point it at
   drivers\audio-ac97 (or tick "AC'97 audio" in setup). Windows may ask
   for the Windows 98 CD for its own WDM audio files; then restart (a
   full power-off and on if a restart hangs).
   After that: a speaker icon in the tray, sounds when Windows starts,
   and Control Panel > Multimedia lists "AC'97 Audio". Try Windows' sounds,
   a music file in Media Player, and the volume slider and mute.
   This first version plays sound (48 kHz stereo; Windows converts other
   rates); recording, the microphone and the other mixer controls are not
   there yet.
   If it fails: send what Device Manager shows for the device, and
   whether the speaker icon appears.

13. USB 2.0 (the MSI 848P Neo2-V's ICH5 has it; also VIA, NEC and other
   add-in cards). Windows 98 shows the controller as "PCI Universal Serial
   Bus" with a yellow mark, or asks for a driver for it. Point it at
   drivers\usb2 (or tick "USB 2.0" in setup). Windows may ask for the
   Windows 98 CD for its usbd.sys. Then a full power-off and on.
   After that: Device Manager lists "Intel 82801EB/ER (ICH5/ICH5R) USB2
   EHCI Controller (KernelExEx)" under Universal Serial Bus controllers.
   USB 1.1 devices work as before. A USB 2.0 device unplugged and plugged
   in again re-installs once per port (it has a new place). What to try:
   - the T2U Plus (step 8) on a USB 2.0 port: KEXNET.LOG should say
     "high speed"; downloads should be much faster than on USB 1.1;
   - a USB 2.0 hub with a mouse or keyboard behind it (this part could
     not be tested in the emulator);
   - unplugging and replugging a USB 2.0 device while Windows runs.
   USB 2.0 sound cards and webcams do not work on it yet; USB flash
   drives need a mass storage driver, which is not done yet.
   If it fails: send C:\WINDOWS\KEXUSB2.LOG (written 20 s after Windows
   starts and every 10 s after) and what Device Manager shows. If the
   boot hangs: Safe mode, Device Manager, remove the USB 2.0 controller.

14. Disks over 128 GB (IDE, and SATA set to IDE mode in the BIOS).
   Windows 98's own IDE driver goes wrong past 128 GB: it wraps around
   and writes over the start of the disk. Do NOT write to a disk over
   128 GB before this step. Tick "Disks over 128 GB" in setup: it
   replaces Windows' driver on every IDE channel, the Windows disk
   included, and also runs CD and DVD drives. A full power-off and on
   after setup.
   After that: Device Manager > Hard disk controllers lists "IDE
   channel (KernelExEx, 48-bit LBA)" for each channel, and System
   Properties > Performance should still say the system is configured
   for best performance (if it mentions MS-DOS compatibility mode, tell
   me). What to try: copy a large folder to the big disk and back,
   compare (fc /b in a DOS box), and CD/DVD reads.
   Partitions: Windows 98's FDISK shows wrong sizes on big disks and
   ScanDisk/Defrag fail on partitions over 127 GB; keep each FAT32
   partition at or under 127 GB (several partitions are fine).
   If it fails: send what Device Manager and the Performance tab show.
   If Windows does not start: Safe mode (F8), then uninstall KernelExEx
   from Control Panel > Add/Remove Programs: that puts Windows' own IDE
   driver back on every channel.

15. USB flash drives and USB disks. Tick "USB flash drives, disks and
   card readers" in setup. With "USB 2.0" ticked too they run at USB 2.0
   speed; without it, at USB 1.1 speed on Windows' own driver.
   Plug the stick in once Windows is running: the first time, Windows
   installs it by itself (it may ask for the Windows 98 CD, for its own
   "1394/USB disk" files) and a new drive letter appears in My Computer,
   no restart. Device Manager > Disk drives lists it.
   What to try: copy a large folder to the stick and back and compare
   (fc /b in a DOS box); a USB card reader; a USB hard disk; unplug and
   plug in again. Before unplugging, wait until the copy has finished
   and the stick's light has stopped: Windows 98 has no "safely remove"
   and keeps writing for a few seconds.
   Known: a stick left in while the PC starts may show up twice (once
   as an extra drive in MS-DOS compatibility mode, because the BIOS
   presents it as a disk); plug it in after Windows has started. USB
   floppy drives do not work yet.
   If it fails: send a photo of Device Manager and the file KEXUSB2.LOG
   from the Windows folder (when USB 2.0 is ticked).

16. Wi-Fi program. Tick "Hardware drivers > Wi-Fi > Realtek USB Wi-Fi
   (TP-Link Archer T2U family and others)" in setup. After a restart,
   plug in the adapter: a Wi-Fi icon (signal bars) appears on the
   taskbar next to the clock. Click it for a quick list, or double-click
   it (or Control Panel > Wi-Fi) for the window: networks in range with
   signal and security. Select yours, Connect, type the password. It is
   remembered and joined by itself from then on. If a network name is
   still set in the adapter's Advanced properties from an older build,
   clear it there first (the window says so).
   Expect: "Connected to <name>" and, within a few seconds, an address
   (ipconfig). Then: tests\kexnet_test.exe get https://example.com/
   Also try: Disconnect / Turn on, Forget, and a restart (it should
   rejoin by itself).
   WEP networks are refused on purpose; WPA3-only and WPA2-Enterprise
   networks are listed but not supported yet.
   If it fails: send a photo of the window and C:\WINDOWS\KEXNET.LOG.

17. Setup. Run it on a fresh install if you can, and look at: the
   pictures, the Components page (groups, "found on this PC" marks on
   the RTL8139, AC'97 and USB 2.0 items on your MSI board), Add/Remove
   Programs afterwards (KernelExEx 1.0.0 test build 12, with the logo),
   and uninstalling. Tell me anything that reads oddly.

18. Virtual machines (only if you use one). In QEMU, VirtualBox or
   Proxmox with a virtio network card, tick "Virtual machines" in setup:
   Windows finds the virtio adapter by itself. In QEMU (standard PC
   machine) and VMware, the mouse moves in and out of the window freely.
   Not needed on your real PC: both parts do nothing there.

19. exFAT cards and sticks (new, optional, READ-ONLY). Tick "Hardware
   drivers > Storage > exFAT drives (read-only, experimental)" in setup
   and restart. SD cards over 32 GB, most USB sticks sold today and
   many external disks come formatted exFAT, which Windows 98 cannot
   read and gives no drive letter. With this, they get a letter.
   Try: a USB stick or card reader with an exFAT card (format it exFAT
   on a newer PC first if you have none; put a few files and a folder
   with a long name on it). Plug it in at the desktop.
   Expect: a new drive letter within a few seconds; Explorer and
   "dir" show the files with long names and right dates; files open
   and copy to C:. Pull it out: the letter goes away.
   Not yet: writing. Copying onto the card gives a "write-protected"
   message; that is expected in this build.
   Note: if the card has no partition table (some cameras format it so)
   and it is plugged in while the PC boots, Windows 98 itself writes a
   few bytes into its first sector. KernelExEx reads such cards fine,
   but a newer PC may then ask to repair it; better plug such cards in
   after Windows has started.
   If it fails: send C:\BOOTLOG.TXT and the card's size and maker.

20. Newer PCs only (optional): SATA in AHCI mode, NVMe SSDs. On boards
   from about 2008 on, the SATA controller usually runs in "AHCI" mode,
   and Windows 98 does not see those disks at all; M.2 NVMe SSDs the
   same. Tick "SATA disks in AHCI mode" and/or "NVMe SSDs" (setup ticks
   them itself when it finds such a controller), restart, and let the
   Add New Hardware wizard install them (it finds them by itself).
   Use them as a second disk first, not the Windows disk.
   Expect: the disks get drive letters, and files copy to and from them.
   SATA DVD drives on the AHCI controller work too.
   Starting Windows from an AHCI disk (from build 21): install this
   first, then switch the BIOS to AHCI. If you switch first, Windows
   still starts (slowly, in "compatibility mode"); the wizard then
   installs the driver and asks to restart, and after that it is fast.
   An NVMe SSD that Windows starts from is left to the BIOS for now
   (works, but slowly); an NVMe SSD holding only data is fast.
   Speed: please time copying a large file (bigger than your RAM) to
   and from the disk and tell us the times, with the CPU, the board
   and the disk.
   If it fails: a photo of the screen, Device Manager's entry for the
   controller, and C:\BOOTLOG.TXT.

21. Laptops only (optional): the battery. Tick "Laptop battery (ACPI)"
   (under "Chipset and sound") and finish setup; no restart needed, but
   the taskbar icon appears at the next start of Windows (or start
   Battery from the KernelExEx Start menu folder now).
   Expect: a battery icon by the clock, filled to the charge; pointing
   at it shows the charge and the time left. Double-click it for the
   details: charge, whether it is charging, capacity, how worn the
   battery is ("% of new"), and the battery's model. Unplug and plug in
   the charger: within a few seconds the icon shows it.
   Please tell us: the laptop's make and model, and whether the charge
   shown matches what the laptop's own indicator lights or BIOS say.
   If it fails: a photo of the Battery window, and the laptop's model.

IF SOMETHING GOES WRONG
  - Hang or crash while booting: press F8 (or hold Ctrl) at boot, pick
    Safe mode. KernelEx stays off in Safe mode. Uninstall it from
    Control Panel > Add/Remove Programs, then reboot.
  - Please note: where it stopped (logo, black screen, which dialog), the
    text of any error box (Details button), and photos are fine.
  - For a boot log: F8 > Logged (BOOTLOG.TXT), then send C:\BOOTLOG.TXT.
  - Network drivers: send C:\WINDOWS\KEXNET.LOG as well; USB 2.0:
    C:\WINDOWS\KEXUSB2.LOG.
  - If a network driver hangs the boot: Safe mode, Device Manager, remove
    that adapter, then unplug it before restarting.

Known open issue: once in about 15 boots in the emulator, startup paused
with an hourglass while KernelEx loaded its TLS library. Tell me if you
ever see a long hourglass on a black screen.

=== Test build 25 (Dell Vostro 1440: install stick) ===
- KernelExEx-USB-Maker.exe (new): makes the install USB stick on any Windows XP-11
  PC in one window. Put your Windows 98 CD in (or Browse to an .iso of it), pick
  the USB stick (at least 1 GB; it is erased), click "Make the USB stick". It asks
  for administrator rights. No Linux, no command line. "Save as .iso file instead"
  makes an image for a CD or a virtual machine. (Replaces the usbkit folder.)
- Fixed: the KernelExEx installer opened during Windows Setup's last phase, and its
  "Reboot now" cut Setup short; the next start then crashed. It now opens on the
  desktop once Setup has finished. This is the likely cause of the blue screen you
  saw "during Setup's restarts" (reproduced in the emulator at any RAM size).
- Windows Setup now runs with /p i (no Windows ACPI driver: it crashes on many
  newer PCs).
- If Windows on the disk stops with an error, start from the stick again: it shows
  the end of Windows' start-up log (BOOTLOG.TXT) before anything else. Please send
  me a photo of that screen.
- New installer component "VESA display driver" (Hardware drivers > Chipset and
  sound): sets the Vostro's Intel HD graphics up with the VESA driver.
- 2 GB RAM: tested in the emulator with 2 GB and a Westmere CPU (close to the
  Vostro's): Setup completes, Windows starts with KEXMEM limiting it to 1 GB.
Tested in QEMU only.

=== Test build 23 (Dell Vostro 1440 batch) ===
New:
- KernelExEx-setup.exe: "HD Audio onboard sound" (Intel HD Audio, Vostro's IDT codec;
  speaker/headphones/volume) and "More than 1 GB of RAM (memory limit)".
- drivers\touch: touchpad / TrackPoint / wheel driver. Device Manager > Mouse >
  (PS/2 mouse) > Properties > Driver > Update Driver > Have Disk > this folder >
  "KernelExEx Touchpad...". Restart. Start > Run "kextouch /settings" for tap,
  scrolling, speeds, and "Save report" (writes C:\KEXTOUCH.TXT - send me that file).
  ALPS v1-v5: tap, two-finger and edge scroll, TrackPoint middle-button scroll.
  Other touchpads: IntelliMouse mode (pointer, buttons, wheel).
- drivers\display: VESA display driver (native resolution e.g. 1366x768 if the BIOS
  offers it). Display Properties > Settings > Advanced > Adapter > Change > Have Disk.
- usbkit: build the install stick from your own CD (MAKE_STICK.TXT), kexmedia.exe writes it.
Tested in QEMU only. Untested on hardware: everything above; please test on the Vostro.
If the touchpad driver misbehaves: Safe Mode, Device Manager, put back "Standard PS/2 Port Mouse".

=== Test build 24 ===
- drivers\keys: kexkeys.exe + kexkeyh.dll - laptop Fn volume/mute/media keys and USB
  keyboard media keys. Copy both files to C:\WINDOWS, run kexkeys.exe (add a shortcut
  to Start > Programs > StartUp to run it at every start). Volume up/down/mute change
  the master volume; play/stop/next/previous control Winamp.
- HD Audio now shows as "HD Audio" (was "AC'97 Audio") in the volume control.
For the install stick: also copy drivers\keys\* into usbkit\extra\KEXINST\ before
running proto_image.py, then they are in C:\KEXINST after installing.
